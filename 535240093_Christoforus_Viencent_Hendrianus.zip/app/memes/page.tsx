'use client';

import { useEffect, useState } from "react";
import Link from "next/link";
import 'bootstrap/dist/css/bootstrap.min.css';

interface Meme {
  id: number;
  title: string;
  imageUrl: string;
  description?: string;
}

export default function MemePage() {
  const [memes, setMemes] = useState<Meme[]>([]);
  const [newTitle, setNewTitle] = useState("");
  const [newImage, setNewImage] = useState("");
  const [loaded, setLoaded] = useState(false); 

  const addMeme = () => {
    if (!newTitle || !newImage) return alert("Tolong isi semua field!");

    const newMeme: Meme = {
      id: Date.now(),
      title: newTitle,
      imageUrl: newImage,
    };

    setMemes([...memes, newMeme]);
    setNewTitle("");
    setNewImage("");
  };


  useEffect(() => {
    const stored = localStorage.getItem("memes");

    if (stored) {
      setMemes(JSON.parse(stored));
    } else {
      const initialMemes: Meme[] = [
        { id: 1, title: "Side Eye", imageUrl: "/images/side_eye.jpeg", description: "Loren Ipsium dolores ..." },
        { id: 2, title: "Uni", imageUrl: "/images/uni.jpeg", description: "Loren Ipsium dolores ..." },
        { id: 3, title: "Tole Tole", imageUrl: "/images/tole_tole.jpg",  description: "Loren Ipsium dolores ..."},
      ];

      setMemes(initialMemes);
      localStorage.setItem("memes", JSON.stringify(initialMemes));
    }

    setLoaded(true);  
  }, []);

  useEffect(() => {
    if (loaded) {
      localStorage.setItem("memes", JSON.stringify(memes));
    }
  }, [memes, loaded]);

  const deleteMeme = (id: number) => {
    setMemes(memes.filter((m) => m.id !== id));
  };

  return (
    <div className="container py-5">
      <h1 className="mb-4 text-center">Cat Meme List</h1>

      {/* Form Add Meme */}
      <div className="card p-4 mb-4">
        <h4>Masukan Nama meme Kucing</h4>

        <div className="row">
          <div className="col-md-4">
            <input
              type="text"
              className="form-control"
              placeholder="Nama meme"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
            />
          </div>

          <div className="col-md-4">
            <input
              type="text"
              className="form-control"
              placeholder="masukkan: /images/name.jpg"
              value={newImage}
              onChange={(e) => setNewImage(e.target.value)}
            />
          </div>

          <div className="col-md-4">
            <button className="btn btn-success w-100" onClick={addMeme}>
              Tambahkan meme
            </button>
          </div>
        </div>
      </div>

      {/* Meme List */}
      <div className="row">
        {memes.map((meme) => (
          <div key={meme.id} className="col-md-4 mb-4">
            <div className="card h-100 shadow-sm">
              <img
                src={meme.imageUrl}
                className="card-img-top"
                alt={meme.title}
                style={{ height: "250px", objectFit: "cover" }}
              />

              <div className="card-body">
                <h5 className="card-title">{meme.title}</h5>
              </div>

              <div className="card-footer d-flex justify-content-between">
                <Link href={`/memes/${meme.id}`} className="btn btn-primary btn-sm">
                  Detail
                </Link>

                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => deleteMeme(meme.id)}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}

        {memes.length === 0 && (
          <p className="text-center">No memes available.</p>
        )}
        
      </div>
    </div>
  );
}
